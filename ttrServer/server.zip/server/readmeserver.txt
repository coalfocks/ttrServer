this is where we'll put all the server files (i.e. plain ol' java stuff)
